# Scripts

Estrutura pensada para rodar datasets diferentes com o mesmo batch genérico.

- `batch/`: execução e sumarização de experimentos.
- `setup/`: checagem de ambiente.
- `preprocessing/`: validação/preparação de CSVs.
- `analysis/`: consolidação/análise após os resultados.
- `utils/`: inspeções rápidas de GPU, resultados e JSONs.
